#include <iostream>

#include "LinkedList.hpp"

int main() {
    LinkedList<int> llist;

    llist.printAllNodes();

    llist.insertAtTheEnd(2);
    llist.insertAtTheEnd(4);
    llist.insertAtTheEnd(6);

    llist.printAllNodes();

    llist.removeNode(llist.findNode(4));

    llist.printAllNodes();

    return 0;
}